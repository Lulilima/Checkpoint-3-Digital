package br.com.fiap.Checkpoint3.repositories;

import br.com.fiap.Checkpoint3.entities.Car;
import org.springframework.data.jpa.repository.JpaRepository;
public interface CarRepository extends JpaRepository<Car, Long> {

}
