package br.com.fiap.Checkpoint3.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Car {
    @Id()
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String brand;

    private String model;

    private int carYear;

    private String color;


    public Long getId(){ return id; }
    public void setId(Long id) {this.id = id; }

    public String getBrand(){ return brand; }
    public void setBrand(String brand){ this.brand = brand;}

    public String getModel(){ return model; }
    public void setModel(String model){ this.model = model;}

    public int getCarYear(){ return carYear; }
    public void setCarYear(int year){ this.carYear = year;}

    public String getColor(){ return color; }
    public void setColor(String color){ this.color = color; }

    public Car(){
    }

    public Car(Long id, String brand, String model, int carYear, String color){

    }
}

